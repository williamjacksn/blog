<?php // Do not delete these lines
  if ('comments.php' == basename($_SERVER['SCRIPT_FILENAME']))
    die ('Please do not load this page directly. THanks!'); ?>

<div id="comments">
  <h3>There <?php comments_number('are no comments','is 1 comment','are % comments'); ?> on '<?php the_title(); ?>'.</h3>

    <ol class="commentlist">

      <?php // Output each comment //
      if ($comments) {
        foreach ($comments as $comment) : ?>
          <li id="comment-<?php comment_ID(); ?>">
            <h4><?php comment_author_link(); ?> said (<?php $entry_datetime = abs(strtotime($post->post_date)); $comment_datetime = abs(strtotime($comment->comment_date)); echo time_since($entry_datetime, $comment_datetime) ?> later):</h4>
            <?php comment_text(); ?><?php edit_comment_link('[edit]'); ?>
          </li>
        <?php endforeach;
      }
      if ('closed' == $post->comment_status) { ?>
        <li id="comment-closed">Comments are closed on this entry.</li>
      <?php } ?>

    </ol>

    <?php if ('open' == $post-> comment_status) : ?>
      <form action="<?php echo get_settings('siteurl'); ?>/wp-comments-post.php" method="post" id="commentform">
      <fieldset>
        <legend id="respond">Leave a comment</legend>
        <input type="hidden" name="comment_post_ID" value="<?php echo $id; ?>" />

        <?php if ($user_ID) { ?>
          <p>Logged in as <a href="<?php echo get_option('siteurl'); ?>/wp-admin/profile.php"><?php echo $user_identity; ?></a>. <a href="<?php echo get_option('siteurl'); ?>/wp-login.php?action=logout" title="<?php _e('Log out of this account') ?>">Logout &raquo;</a></p>
        <?php } else { ?>
          <p><input type="text" name="author" id="author" value="<?php echo $comment_author; ?>" size="22" tabindex="1" />
             <label for="author">Name <?php if ($req) _e('(required)'); ?></label></p>

          <p><input type="text" name="email" id="email" value="<?php echo $comment_author_email; ?>" size="22" tabindex="2" />
             <label for="email">Email (<?php if ($req) _e('required / '); ?>never displayed)</label></p>

          <p><input type="text" name="url" id="url" value="<?php echo $comment_author_url; ?>" size="22" tabindex="3" />
             <label for="url">Website (if you want your name to link)</label></p>
        <?php } ?>

          <p><textarea name="comment" id="comment" rows="6" tabindex="4"></textarea></p>

          <p><input name="submit" type="submit" id="submit" tabindex="5" value="Submit Comment" /></p>
        <?php do_action('comment_form', $post->ID); ?>
      </fieldset>
      </form>

    <?php endif; // if you delete this the sky will fall on your head // ?>

</div>