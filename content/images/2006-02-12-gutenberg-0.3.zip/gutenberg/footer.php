    <div id="footer">
      <ul>
        <li><?php posts_nav_link(' &mdash; ', '&laquo; Previous Page', 'Next Page &raquo;'); ?></li>
        <li id="search">
          <form id="searchform" method="get" action="<?php echo $_SERVER['PHP_SELF']; ?>">
            <input type="text" name="s" id="s" size="15" />
            <input type="submit" value="<?php _e('Search'); ?>" />
          </form>
        </li>
      </ul>
    </div>

  </div> <?php /* end of container */ ?>
</body>

</html>