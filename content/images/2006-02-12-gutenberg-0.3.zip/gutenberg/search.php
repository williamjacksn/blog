<?php get_header(); ?>

    <div id="content">

    <?php if (have_posts()) : while (have_posts()) : the_post(); ?>

      <div class="post">
        <h2 id="post-<?php the_ID(); ?>"><a href="<?php the_permalink() ?>" rel="bookmark"><?php the_title(); ?></a></h2>
        <h3>written <?php echo get_the_time('j F Y'); ?>, <?php the_time(); ?></h3>

        <div class="post-body">
          <?php the_excerpt(); ?>
        </div>

        <div class="post-footer">
        </div>
      </div>

    <?php endwhile; else: ?>
      <p class="search-fail"><?php _e('This space is intentionally left blank.'); ?></p>
      <div class="post"></div>
    <?php endif; ?>



</div>

<?php get_footer(); ?>
