<?php get_header(); ?>

    <div id="content">

    <?php if (have_posts()) : while (have_posts()) : the_post(); ?>

      <div class="post">
        <h2 id="post-<?php the_ID(); ?>"><a href="<?php the_permalink() ?>" rel="bookmark"><?php the_title(); ?></a></h2>
        <h3>written <?php echo get_the_time('j F Y'); ?>, <?php the_time(); ?></h3>
        <?php edit_post_link('Edit this entry','<p class="edit-link">[',']</p>'); ?>

        <div class="post-body">
          <?php the_content('Continue reading &raquo;'); ?>
        </div>

        <div class="post-footer">
          <ul>
            <li>written by <?php the_author() ?></li>
            <li>categorized as <?php the_category(',') ?></li>
          </ul>
        </div>
      </div>

<?php comments_template(); ?>

<?php endwhile; else: ?>
<p><?php _e('Sorry, no posts matched your criteria.'); ?></p>
<?php endif; ?>

<?php posts_nav_link(' &#8212; ', __('&laquo; Previous Page'), __('Next Page &raquo;')); ?>

</div>

<?php get_footer(); ?>
