<?php

  /*
    MovablePress
    http://subtlecoolness.com/projects/movablepress/

    William Jackson wrote this. It pulls Wordpress posts and comments
    directly from the database and creates a file that can be imported
    into Movable Type.

    Questions go to <william@subtlecoolness.com>.
  */

  header('Content-type: text/plain');

  // Important database information
  $db_host = 'localhost';
  $db_user = '';
  $db_pass = '';
  $db_name = '';

  // If you didn't use the default table prefix when you installed
  // WordPress, you will need to change this.
  $db_table_prefix = 'wp_';

  // Connect to the database server
  $db_connect = mysql_connect($db_host, $db_user, $db_pass);
  if (!$db_connect)
  {
    die('Could not connect: ' . mysql_error());
  }

  // Select the database
  $db_select = mysql_select_db($db_name, $db_connect);
  if (!$db_select)
  {
    die('Could not select database: ' . mysql_error());
  }

  // Query the database for the list of posts
  $posts = mysql_query("select * from " . $db_table_prefix . "posts");
  if (!$posts)
  {
    die('Could not query the database: ' . mysql_error());
  }

  $number_of_posts = mysql_num_rows($posts);

  // For each post ...
  $i = 0;
  while ($i < $number_of_posts)
  {
    // We'll need you later on.
    $post_id = mysql_result($posts, $i, 'ID');

    // TITLE
    $post_title = mysql_result($posts, $i, 'post_title');
    echo "TITLE: $post_title\n";

    // DATE
    $mysql_post_date = mysql_result($posts, $i, 'post_date');
    $post_timestamp = strtotime($mysql_post_date);
    $php_post_date = date('m/d/Y H:i:s', $post_timestamp);
    echo "DATE: $php_post_date\n";

    // CATEGORY
    // Query the database for the list of categories for this post
    $cats = mysql_query("select * from $db_table_prefix" .
                        "post2cat where post_id=$post_id");
    $number_of_cats = mysql_num_rows($cats);
    
    // For each category ...
    $j = 0;
    while ($j < $number_of_cats)
    {
      $cat_id = mysql_result($cats, $j, 'category_id');
      $cat_name_result = mysql_query("select * from $db_table_prefix" .
                                     "categories where cat_ID=$cat_id");
      $cat_name = mysql_result($cat_name_result, 0, 'cat_name');
      echo "CATEGORY: $cat_name\n";
      mysql_free_result($cat_name_result);
      $j++;
    }

    mysql_free_result($cats);

    // STATUS
    // |--------------------------------------|
    // | WordPress value | Movable Type value |
    // |-----------------|--------------------|
    // | publish         | publish            |
    // | static          | publish            |
    // | draft           | draft              |
    // | private         | draft              |
    // | object          | draft              |
    // |-----------------|--------------------|
    $wp_post_status = mysql_result($posts, $i, 'post_status');
    if (($wp_post_status == 'publish') || $wp_post_status == ('static'))
    {
      $post_status = 'publish';
    }
    else
    {
      $post_status = 'draft';
    }
    echo "STATUS: $post_status\n";

    // ALLOW COMMENTS
    // |----------------------------------------|
    // | WordPress values | Movable Type values |
    // |------------------|---------------------|
    // | closed           | 0                   |
    // | open             | 1                   |
    // | registered_only  | 1                   |
    // |----------------------------------------|
    $wp_allow_comments = mysql_result($posts, $i, 'comment_status');
    if ($wp_allow_comments == 'closed')
    {
      $allow_comments = '0';
    }
    else
    {
      $allow_comments = '1';
    }
    echo "ALLOW COMMENTS: $allow_comments\n";

    // ALLOW PINGS
    // |----------------------------------------|
    // | WordPress values | Movable Type values |
    // |------------------|---------------------|
    // | open             | 1                   |
    // | closed           | 0                   |
    // |----------------------------------------|
    $wp_allow_pings = mysql_result($posts, $i, 'ping_status');
    if ($wp_allow_pings == 'open')
    {
      $allow_pings = '1';
    }
    else
    {
      $allow_pings = '0';
    }
    echo "ALLOW PINGS: $allow_pings\n";

    // CONVERT BREAKS
    // There isn't a similar per-post setting in WordPress.

    echo "-----\n";

    // KEYWORDS

    // BODY
    $post_body = mysql_result($posts, $i, 'post_content');
    echo "BODY:\n";
    echo "$post_body\n";
    echo "-----\n";

    // EXCERPT
    $post_excerpt = mysql_result($posts, $i, 'post_excerpt');
    echo "EXCERPT:\n";
    echo "$post_excerpt\n";
    echo "-----\n";

    // Query the database for the comments on this post
    $cs = mysql_query("select * from $db_table_prefix" .
                            "comments where comment_post_ID=$post_id " .
                            "and comment_approved='1'");
    $number_of_comments = mysql_num_rows($cs);

    // For each comment ...
    $k = 0;
    while ($k < $number_of_comments)
    {
      echo "COMMENT:\n";

      // Comment AUTHOR
      $c_author = mysql_result($cs, $k, 'comment_author');
      echo "AUTHOR: $c_author\n";

      // Comment author EMAIL
      $c_author_email = mysql_result($cs, $k, 'comment_author_email');
      echo "EMAIL: $c_author_email\n";

      // Comment author URL
      $c_author_url = mysql_result($cs, $k, 'comment_author_url');
      echo "URL: $c_author_url\n";

      // Comment author IP
      $c_author_ip = mysql_result($cs, $k, 'comment_author_IP');
      echo "IP: $c_author_ip\n";

      // Comment DATE
      $mysql_c_date = mysql_result($cs, $k, 'comment_date');
      $c_timestamp = strtotime($mysql_c_date);
      $php_c_date = date('m/d/Y H:i:s', $c_timestamp);
      echo "DATE: $php_c_date\n";

      // Comment body
      $c_body = mysql_result($cs, $k, 'comment_content');
      echo "$c_body\n";

      // This comment is done
      echo "-----\n";
      $k++;
    }

    // PINGS
    // Not implemented.

    // This post is done
    echo "--------\n";
    mysql_free_result($cs);
    $i++;
  }

  mysql_free_result($posts);

?>
